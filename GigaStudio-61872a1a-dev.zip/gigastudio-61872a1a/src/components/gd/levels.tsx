import { Star } from "lucide-react";
import { ExternalLink } from "lucide-react";
import {
  difficulties,
  levels,
  type DifficultyId,
} from "@/lib/gd-data";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { SectionHeading } from "./section-heading";

const difficultyById = new Map(difficulties.map((d) => [d.id, d]));

function walkthroughUrl(name: string) {
  return `https://www.youtube.com/results?search_query=${encodeURIComponent(
    `Geometry Dash ${name} прохождение`,
  )}`;
}

function DifficultyBadge({ id }: { id: DifficultyId }) {
  const difficulty = difficultyById.get(id);
  if (!difficulty) return null;
  return (
    <span
      className="inline-flex whitespace-nowrap rounded-full px-2.5 py-0.5 text-xs font-semibold"
      style={{
        color: difficulty.color,
        backgroundColor: `${difficulty.color}1f`,
      }}
    >
      {difficulty.name}
    </span>
  );
}

export function Levels() {
  return (
    <section id="levels" className="scroll-mt-32">
      <div className="mx-auto max-w-6xl px-4 py-16 sm:py-20">
        <SectionHeading
          kicker="Уровни"
          title="Все 22 официальных уровня"
          description="Полный список трасс основной игры: сложность, звёзды, версия, в которой уровень появился, и трек, под который он проходится."
        />
        <div className="rounded-xl border border-white/10 bg-white/5">
          <Table>
            <TableHeader>
              <TableRow className="border-white/10 hover:bg-transparent">
                <TableHead className="pl-4 text-slate-400">№</TableHead>
                <TableHead className="text-slate-400">Уровень</TableHead>
                <TableHead className="text-slate-400">Сложность</TableHead>
                <TableHead className="text-slate-400">Звёзды</TableHead>
                <TableHead className="text-slate-400">Версия</TableHead>
                <TableHead className="pr-4 text-slate-400">Музыка</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {levels.map((level) => (
                <TableRow key={level.n} className="border-white/10">
                  <TableCell className="pl-4 font-mono text-sm text-slate-500">
                    {level.n}
                  </TableCell>
                  <TableCell className="font-medium">
                    <a
                      href={walkthroughUrl(level.name)}
                      target="_blank"
                      rel="noopener noreferrer"
                      aria-label={`Прохождение уровня ${level.name} на YouTube`}
                      className="inline-flex items-center gap-1.5 text-white transition-colors hover:text-cyan-300"
                    >
                      {level.name}
                      <ExternalLink
                        className="size-3.5 opacity-60"
                        aria-hidden
                      />
                    </a>
                  </TableCell>
                  <TableCell>
                    <DifficultyBadge id={level.difficulty} />
                  </TableCell>
                  <TableCell>
                    <span className="inline-flex items-center gap-1 text-sm text-amber-300">
                      <Star className="size-3.5 fill-amber-300" aria-hidden />
                      {level.stars}
                    </span>
                  </TableCell>
                  <TableCell className="font-mono text-sm text-slate-400">
                    {level.version}
                  </TableCell>
                  <TableCell className="pr-4 text-sm text-slate-400">
                    {level.song}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
        <p className="mt-4 text-sm text-slate-500">
          Нажмите на название уровня, чтобы открыть прохождение на YouTube.
          Кроме основных трасс есть секретные уровни: The Challenge и башня из
          обновления 2.2 — они не входят в основной список.
        </p>
      </div>
    </section>
  );
}
