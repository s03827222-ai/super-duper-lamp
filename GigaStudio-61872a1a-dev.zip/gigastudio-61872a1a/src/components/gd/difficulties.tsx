import { Star } from "lucide-react";
import { difficulties } from "@/lib/gd-data";
import { SectionHeading } from "./section-heading";

export function Difficulties() {
  return (
    <section id="difficulties" className="scroll-mt-32 border-t border-white/5">
      <div className="mx-auto max-w-6xl px-4 py-16 sm:py-20">
        <SectionHeading
          kicker="Сложности"
          title="Шесть ступеней к демону"
          description="Каждому уровню присвоена сложность и звёзды — чем их больше, тем ценнее награда за прохождение."
        />
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {difficulties.map((difficulty) => (
            <article
              key={difficulty.id}
              className="relative overflow-hidden rounded-xl border border-white/10 bg-white/5 p-5"
            >
              <span
                aria-hidden
                className="absolute inset-x-0 top-0 h-1"
                style={{
                  background: difficulty.color,
                  boxShadow: `0 0 18px ${difficulty.color}`,
                }}
              />
              <div className="flex items-center justify-between gap-2">
                <h3
                  className="font-display text-lg uppercase tracking-wide"
                  style={{ color: difficulty.color }}
                >
                  {difficulty.name}
                </h3>
                <span
                  className="inline-flex items-center gap-1 rounded-full px-2.5 py-0.5 text-xs font-semibold"
                  style={{
                    color: difficulty.color,
                    backgroundColor: `${difficulty.color}1f`,
                  }}
                >
                  <Star className="size-3.5" aria-hidden />
                  {difficulty.stars}
                </span>
              </div>
              <p className="mt-3 text-sm text-slate-400">
                {difficulty.description}
              </p>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
