const navItems = [
  { href: "#about", label: "Об игре" },
  { href: "#rules", label: "Правила" },
  { href: "#modes", label: "Режимы" },
  { href: "#difficulties", label: "Сложности" },
  { href: "#levels", label: "Уровни" },
  { href: "#game", label: "Мини-игра" },
  { href: "#features", label: "Возможности" },
  { href: "#updates", label: "Обновления" },
  { href: "#faq", label: "FAQ" },
];

function CubeMark() {
  return (
    <span
      aria-hidden
      className="grid size-8 shrink-0 place-items-center rounded-md bg-gradient-to-br from-cyan-300 to-cyan-500 shadow-[0_0_16px_rgba(34,211,238,0.55)]"
    >
      <span className="flex gap-1">
        <span className="size-1.5 rounded-[2px] bg-slate-900" />
        <span className="size-1.5 rounded-[2px] bg-slate-900" />
      </span>
    </span>
  );
}

export function SiteHeader() {
  return (
    <header className="sticky top-0 z-50 border-b border-white/10 bg-[#0b0f1e]/85 backdrop-blur">
      <div className="mx-auto flex h-16 max-w-6xl items-center justify-between gap-3 px-4">
        <a href="#top" className="flex items-center gap-2.5">
          <CubeMark />
          <span className="font-display text-sm uppercase tracking-wider text-white sm:text-base">
            Geometry Dash
          </span>
        </a>
        <nav
          aria-label="Разделы сайта"
          className="hidden items-center gap-0.5 xl:flex"
        >
          {navItems.map((item) => (
            <a
              key={item.href}
              href={item.href}
              className="rounded-full px-2.5 py-1.5 text-sm text-slate-300 transition-colors hover:bg-white/10 hover:text-white"
            >
              {item.label}
            </a>
          ))}
        </nav>
        <a
          href="#levels"
          className="hidden rounded-full bg-cyan-400 px-4 py-2 text-sm font-semibold text-slate-950 transition-colors hover:bg-cyan-300 xl:inline-flex"
        >
          Все уровни
        </a>
      </div>
      <nav
        aria-label="Разделы сайта"
        className="flex gap-1.5 overflow-x-auto px-4 pb-3 xl:hidden"
      >
        {navItems.map((item) => (
          <a
            key={item.href}
            href={item.href}
            className="whitespace-nowrap rounded-full border border-white/10 px-3 py-1.5 text-sm text-slate-300 transition-colors hover:bg-white/10 hover:text-white"
          >
            {item.label}
          </a>
        ))}
      </nav>
    </header>
  );
}
