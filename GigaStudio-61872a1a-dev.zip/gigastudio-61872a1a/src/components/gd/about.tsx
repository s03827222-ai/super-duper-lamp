import type { LucideIcon } from "lucide-react";
import { CalendarDays, Code, MonitorSmartphone, Music } from "lucide-react";
import { aboutFacts } from "@/lib/gd-data";
import { SectionHeading } from "./section-heading";

const icons: Record<(typeof aboutFacts)[number]["icon"], LucideIcon> = {
  dev: Code,
  date: CalendarDays,
  genre: Music,
  platforms: MonitorSmartphone,
};

export function About() {
  return (
    <section id="about" className="scroll-mt-32 border-t border-white/5">
      <div className="mx-auto max-w-6xl px-4 py-16 sm:py-20">
        <SectionHeading
          kicker="Об игре"
          title="Что такое Geometry Dash"
          description="Один тап, одна ошибка — и сначала. За этой простой идеей прячется одна из самых хардкорных игр в мире."
        />
        <div className="grid gap-10 lg:grid-cols-[1.2fr_1fr] lg:gap-16">
          <div className="space-y-4 text-slate-300">
            <p>
              Geometry Dash — ритм-платформер Роберта Топалы, вышедший 13
              августа 2013 года. Квадратик несётся вперёд сам, а вы одним
              касанием прыгаете в такт музыке: через шипы, по блокам, сквозь
              порталы. Малейшая ошибка — и уровень начинается заново, поэтому
              каждый трюк приходится доводить до автоматизма.
            </p>
            <p>
              Вторая половина игры — сообщество. Встроенный редактор позволяет
              строить собственные уровни, а онлайн-каталог пополняется
              ежедневными трассами, гаунтлетами и маппаками от игроков. Есть и
              бесплатные спин-оффы: Geometry Dash Lite, World, Meltdown и
              SubZero.
            </p>
          </div>
          <dl className="grid gap-3 sm:grid-cols-2 lg:grid-cols-1">
            {aboutFacts.map((fact) => {
              const Icon = icons[fact.icon];
              return (
                <div
                  key={fact.label}
                  className="flex items-center gap-4 rounded-xl border border-white/10 bg-white/5 px-4 py-3"
                >
                  <span className="grid size-10 shrink-0 place-items-center rounded-lg bg-cyan-400/15 text-cyan-300">
                    <Icon className="size-5" aria-hidden />
                  </span>
                  <div>
                    <dt className="text-xs uppercase tracking-wide text-slate-500">
                      {fact.label}
                    </dt>
                    <dd className="text-sm font-medium text-white">
                      {fact.value}
                    </dd>
                  </div>
                </div>
              );
            })}
          </dl>
        </div>
      </div>
    </section>
  );
}
