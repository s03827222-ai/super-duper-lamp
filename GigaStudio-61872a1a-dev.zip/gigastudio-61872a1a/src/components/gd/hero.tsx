import Image from "next/image";
import { ChevronDown } from "lucide-react";

const stats = [
  { value: "22", label: "официальных уровня" },
  { value: "8", label: "режимов игры" },
  { value: "6", label: "уровней сложности" },
  { value: "2.2", label: "актуальная версия" },
];

export function Hero() {
  return (
    <section id="top" className="relative overflow-hidden">
      <div className="absolute inset-0">
        <Image
          src="/hero-gd.webp"
          alt=""
          fill
          priority
          sizes="100vw"
          className="object-cover object-center"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-[#0b0f1e]/60 via-[#0b0f1e]/40 to-[#0b0f1e]" />
      </div>
      <div className="relative mx-auto flex max-w-6xl flex-col items-center px-4 pb-16 pt-20 text-center sm:pb-24 sm:pt-28">
        <p className="mb-4 rounded-full border border-cyan-300/40 bg-cyan-400/10 px-4 py-1.5 text-xs font-bold uppercase tracking-[0.2em] text-cyan-300">
          Фан-гид по игре
        </p>
        <h1 className="font-display text-4xl uppercase leading-tight text-white drop-shadow-[0_0_24px_rgba(34,211,238,0.35)] sm:text-6xl">
          Geometry Dash
        </h1>
        <p className="mt-5 max-w-2xl text-balance text-base text-slate-300 sm:text-lg">
          Ритм-платформер, где один тап решает всё: прыгай в такт музыке,
          проходи порталы и не останавливайся — любая ошибка возвращает в
          начало.
        </p>
        <div className="mt-8 flex flex-wrap items-center justify-center gap-3">
          <a
            href="#levels"
            className="rounded-full bg-cyan-400 px-6 py-3 text-sm font-bold uppercase tracking-wide text-slate-950 shadow-[0_0_24px_rgba(34,211,238,0.45)] transition-colors hover:bg-cyan-300"
          >
            Все уровни
          </a>
          <a
            href="#faq"
            className="rounded-full border border-white/20 bg-white/5 px-6 py-3 text-sm font-bold uppercase tracking-wide text-white transition-colors hover:bg-white/10"
          >
            Частые вопросы
          </a>
        </div>
        <dl className="mt-14 grid w-full max-w-3xl grid-cols-2 gap-3 sm:grid-cols-4">
          {stats.map((stat) => (
            <div
              key={stat.label}
              className="rounded-xl border border-white/10 bg-[#0b0f1e]/70 px-3 py-4 backdrop-blur"
            >
              <dt className="order-2 mt-1 block text-xs text-slate-400">
                {stat.label}
              </dt>
              <dd className="font-display text-2xl text-cyan-300">
                {stat.value}
              </dd>
            </div>
          ))}
        </dl>
        <a
          href="#about"
          aria-label="Листайте вниз"
          className="mt-12 animate-bounce text-slate-500 transition-colors hover:text-cyan-300 motion-reduce:animate-none"
        >
          <ChevronDown className="size-6" aria-hidden />
        </a>
      </div>
    </section>
  );
}
