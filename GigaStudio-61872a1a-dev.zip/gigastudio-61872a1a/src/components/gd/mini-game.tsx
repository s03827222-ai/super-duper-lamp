"use client";

import { useEffect, useRef, useState } from "react";
import {
  BookOpen,
  Heart,
  MousePointerClick,
  RotateCcw,
  Trophy,
} from "lucide-react";
import { SectionHeading } from "./section-heading";

const GAME_TIME = 30;
const MAX_ESCAPES = 5;
const BEST_KEY = "gd-cube-rush-best";

const PALETTES = [
  ["#22d3ee", "#0e7490"],
  ["#e879f9", "#a21caf"],
  ["#fbbf24", "#b45309"],
  ["#4ade80", "#15803d"],
] as const;

type Status = "idle" | "playing" | "over";

type Cube = {
  x: number;
  baseY: number;
  size: number;
  vx: number;
  amp: number;
  freq: number;
  phase: number;
  rot: number;
  vrot: number;
  palette: number;
};

type Particle = {
  x: number;
  y: number;
  vx: number;
  vy: number;
  size: number;
  rot: number;
  vrot: number;
  life: number;
  maxLife: number;
  color: string;
  spark: boolean;
};

type Popup = { x: number; y: number; text: string; life: number; color: string };
type Ring = { x: number; y: number; r: number; life: number; color: string };

type World = {
  cubes: Cube[];
  particles: Particle[];
  popups: Popup[];
  rings: Ring[];
  spawnTimer: number;
  elapsed: number;
  gridOffset: number;
  shake: number;
  timeLeft: number;
  escapes: number;
  combo: number;
};

const freshWorld = (): World => ({
  cubes: [],
  particles: [],
  popups: [],
  rings: [],
  spawnTimer: 0.4,
  elapsed: 0,
  gridOffset: 0,
  shake: 0,
  timeLeft: GAME_TIME,
  escapes: 0,
  combo: 0,
});

const cubeY = (cube: Cube, elapsed: number) =>
  cube.baseY + Math.sin(elapsed * cube.freq + cube.phase) * cube.amp;

function traceRoundRect(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  w: number,
  h: number,
  r: number,
) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.arcTo(x + w, y, x + w, y + h, r);
  ctx.arcTo(x + w, y + h, x, y + h, r);
  ctx.arcTo(x, y + h, x, y, r);
  ctx.arcTo(x, y, x + w, y, r);
  ctx.closePath();
}

function GameCanvas() {
  const wrapRef = useRef<HTMLDivElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const ctxRef = useRef<CanvasRenderingContext2D | null>(null);
  const worldRef = useRef<World>(freshWorld());
  const rafRef = useRef(0);
  const lastRef = useRef(0);
  const statusRef = useRef<Status>("idle");
  const scoreRef = useRef(0);
  const bestRef = useRef(0);
  const sizeRef = useRef({ w: 0, h: 0 });
  const reducedRef = useRef(false);
  const timeShownRef = useRef(GAME_TIME);
  const drawRef = useRef<() => void>(() => {});

  const [status, setStatus] = useState<Status>("idle");
  const [score, setScore] = useState(0);
  const [best, setBest] = useState(0);
  const [combo, setCombo] = useState(0);
  const [lives, setLives] = useState(MAX_ESCAPES);
  const [timeLeft, setTimeLeft] = useState(GAME_TIME);
  const [endTitle, setEndTitle] = useState("Время вышло!");

  const spawnCube = (progress: number) => {
    const { w, h } = sizeRef.current;
    const margin = 40;
    const minY = margin;
    const maxY = Math.max(minY + 20, h - margin - 20);
    worldRef.current.cubes.push({
      x: w + 50,
      baseY: minY + Math.random() * (maxY - minY),
      size: 34 + Math.random() * 22,
      vx: -(150 + progress * 210 + Math.random() * 90),
      amp: reducedRef.current ? 3 : 6 + Math.random() * 12,
      freq: 1.2 + Math.random() * 1.8,
      phase: Math.random() * Math.PI * 2,
      rot: (Math.random() - 0.5) * 0.5,
      vrot: (Math.random() - 0.5) * 1.4,
      palette: Math.floor(Math.random() * PALETTES.length),
    });
  };

  const burst = (x: number, y: number, palette: number, big: boolean) => {
    const world = worldRef.current;
    const [c1 = "#22d3ee", c2 = "#0e7490"] = PALETTES[palette] ?? [];
    const fragments = big && !reducedRef.current ? 12 : big ? 6 : 4;
    for (let i = 0; i < fragments; i++) {
      const life = 0.5 + Math.random() * 0.4;
      world.particles.push({
        x: x + (Math.random() - 0.5) * 18,
        y: y + (Math.random() - 0.5) * 18,
        vx: (Math.random() - 0.5) * 340,
        vy: -80 - Math.random() * 260,
        size: 4 + Math.random() * 7,
        rot: Math.random() * Math.PI,
        vrot: (Math.random() - 0.5) * 10,
        life,
        maxLife: life,
        color: Math.random() < 0.5 ? c1 : c2,
        spark: false,
      });
    }
    const sparks = big && !reducedRef.current ? 8 : 3;
    for (let i = 0; i < sparks; i++) {
      const life = 0.25 + Math.random() * 0.25;
      world.particles.push({
        x,
        y,
        vx: (Math.random() - 0.5) * 480,
        vy: (Math.random() - 0.5) * 480,
        size: 1.5 + Math.random() * 2,
        rot: 0,
        vrot: 0,
        life,
        maxLife: life,
        color: c1,
        spark: true,
      });
    }
    if (big) world.rings.push({ x, y, r: 12, life: 0.35, color: c1 });
  };

  const smash = (cube: Cube, index: number) => {
    const world = worldRef.current;
    world.cubes.splice(index, 1);
    world.combo += 1;
    setCombo(world.combo);
    const bonus = world.combo % 5 === 0 ? 5 : 0;
    const gain = 1 + bonus;
    scoreRef.current += gain;
    setScore(scoreRef.current);
    const y = cubeY(cube, world.elapsed);
    burst(cube.x, y, cube.palette, true);
    world.popups.push({
      x: cube.x,
      y: y - cube.size / 2 - 10,
      text: bonus > 0 ? `+${gain} · комбо ×${world.combo}` : `+${gain}`,
      life: 0.9,
      color: bonus > 0 ? "#e879f9" : "#67e8f9",
    });
    if (!reducedRef.current) world.shake = 0.18;
  };

  const endGame = (title: string) => {
    statusRef.current = "over";
    setEndTitle(title);
    setStatus("over");
    bestRef.current = Math.max(bestRef.current, scoreRef.current);
    setBest(bestRef.current);
    try {
      window.localStorage.setItem(BEST_KEY, String(bestRef.current));
    } catch {}
    cancelAnimationFrame(rafRef.current);
  };

  const update = (dt: number) => {
    const world = worldRef.current;
    world.elapsed += dt;
    world.gridOffset = (world.gridOffset + 90 * dt) % 64;
    if (world.shake > 0) world.shake = Math.max(0, world.shake - dt);
    const progress = Math.min(1, world.elapsed / GAME_TIME);
    world.timeLeft -= dt;

    world.spawnTimer -= dt;
    if (world.spawnTimer <= 0) {
      spawnCube(progress);
      world.spawnTimer =
        Math.max(0.32, 1.05 - progress * 0.55) * (0.75 + Math.random() * 0.5);
    }

    for (let i = world.cubes.length - 1; i >= 0; i--) {
      const cube = world.cubes[i];
      cube.x += cube.vx * dt;
      cube.rot += cube.vrot * dt;
      if (cube.x + cube.size / 2 < 0) {
        world.cubes.splice(i, 1);
        world.combo = 0;
        setCombo(0);
        world.escapes += 1;
        setLives(MAX_ESCAPES - world.escapes);
        world.popups.push({
          x: 70,
          y: Math.max(30, cubeY(cube, world.elapsed)),
          text: "Улетел!",
          life: 0.9,
          color: "#f87171",
        });
        if (!reducedRef.current) world.shake = 0.12;
      }
    }

    for (let i = world.particles.length - 1; i >= 0; i--) {
      const p = world.particles[i];
      p.life -= dt;
      if (p.life <= 0) {
        world.particles.splice(i, 1);
        continue;
      }
      p.x += p.vx * dt;
      p.y += p.vy * dt;
      if (!p.spark) p.vy += 900 * dt;
      p.rot += p.vrot * dt;
    }

    for (let i = world.rings.length - 1; i >= 0; i--) {
      const ring = world.rings[i];
      ring.life -= dt;
      ring.r += 260 * dt;
      if (ring.life <= 0) world.rings.splice(i, 1);
    }

    for (let i = world.popups.length - 1; i >= 0; i--) {
      const popup = world.popups[i];
      popup.life -= dt;
      popup.y -= 34 * dt;
      if (popup.life <= 0) world.popups.splice(i, 1);
    }

    const shown = Math.max(0, Math.ceil(world.timeLeft));
    if (shown !== timeShownRef.current) {
      timeShownRef.current = shown;
      setTimeLeft(shown);
    }

    if (world.timeLeft <= 0) endGame("Время вышло!");
    else if (world.escapes >= MAX_ESCAPES) {
      endGame("Слишком много кубов улетело!");
    }
  };

  const draw = () => {
    const ctx = ctxRef.current;
    if (!ctx) return;
    const { w, h } = sizeRef.current;
    const world = worldRef.current;

    ctx.clearRect(0, 0, w, h);
    const bg = ctx.createLinearGradient(0, 0, 0, h);
    bg.addColorStop(0, "#0b0f1e");
    bg.addColorStop(1, "#111a36");
    ctx.fillStyle = bg;
    ctx.fillRect(0, 0, w, h);

    ctx.save();
    if (world.shake > 0) {
      const mag = world.shake * 26;
      ctx.translate((Math.random() - 0.5) * mag, (Math.random() - 0.5) * mag);
    }

    ctx.strokeStyle = "rgba(148, 163, 184, 0.08)";
    ctx.lineWidth = 1;
    ctx.beginPath();
    for (let x = -world.gridOffset; x < w + 64; x += 64) {
      ctx.moveTo(x, 0);
      ctx.lineTo(x, h);
    }
    for (let y = 0; y < h; y += 64) {
      ctx.moveTo(0, y);
      ctx.lineTo(w, y);
    }
    ctx.stroke();

    const groundY = h - 34;
    ctx.fillStyle = "rgba(34, 211, 238, 0.06)";
    ctx.fillRect(0, groundY, w, h - groundY);
    ctx.strokeStyle = "rgba(34, 211, 238, 0.4)";
    ctx.setLineDash([18, 14]);
    ctx.lineDashOffset = -world.gridOffset * 2;
    ctx.beginPath();
    ctx.moveTo(0, groundY);
    ctx.lineTo(w, groundY);
    ctx.stroke();
    ctx.setLineDash([]);

    for (const ring of world.rings) {
      ctx.globalAlpha = Math.max(0, ring.life / 0.35);
      ctx.strokeStyle = ring.color;
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(ring.x, ring.y, ring.r, 0, Math.PI * 2);
      ctx.stroke();
    }
    ctx.globalAlpha = 1;

    for (const cube of world.cubes) {
      const [c1 = "#22d3ee", c2 = "#0e7490"] = PALETTES[cube.palette] ?? [];
      const s = cube.size;
      ctx.save();
      ctx.translate(cube.x, cubeY(cube, world.elapsed));
      ctx.rotate(cube.rot);
      ctx.shadowColor = c1;
      ctx.shadowBlur = 16;
      const grad = ctx.createLinearGradient(-s / 2, -s / 2, s / 2, s / 2);
      grad.addColorStop(0, c1);
      grad.addColorStop(1, c2);
      ctx.fillStyle = grad;
      traceRoundRect(ctx, -s / 2, -s / 2, s, s, 6);
      ctx.fill();
      ctx.shadowBlur = 0;
      ctx.strokeStyle = "rgba(255, 255, 255, 0.28)";
      ctx.lineWidth = 1.5;
      ctx.stroke();
      ctx.fillStyle = "rgba(11, 15, 30, 0.85)";
      const eye = s * 0.16;
      ctx.fillRect(-s * 0.26, -s * 0.18, eye, s * 0.2);
      ctx.fillRect(s * 0.1, -s * 0.18, eye, s * 0.2);
      ctx.fillRect(-s * 0.16, s * 0.14, s * 0.32, s * 0.08);
      ctx.restore();
    }

    for (const p of world.particles) {
      ctx.globalAlpha = Math.max(0, p.life / p.maxLife);
      if (p.spark) {
        ctx.fillStyle = p.color;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
        ctx.fill();
      } else {
        ctx.save();
        ctx.translate(p.x, p.y);
        ctx.rotate(p.rot);
        ctx.fillStyle = p.color;
        ctx.fillRect(-p.size / 2, -p.size / 2, p.size, p.size);
        ctx.restore();
      }
    }
    ctx.globalAlpha = 1;

    ctx.textAlign = "center";
    ctx.font = "700 14px ui-monospace, monospace";
    for (const popup of world.popups) {
      ctx.globalAlpha = Math.min(1, Math.max(0, popup.life / 0.6));
      ctx.fillStyle = popup.color;
      ctx.fillText(popup.text, popup.x, popup.y);
    }
    ctx.globalAlpha = 1;
    ctx.restore();
  };

  useEffect(() => {
    drawRef.current = draw;
  });

  useEffect(() => {
    const wrap = wrapRef.current;
    const canvas = canvasRef.current;
    if (!wrap || !canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    ctxRef.current = ctx;
    reducedRef.current = window.matchMedia(
      "(prefers-reduced-motion: reduce)",
    ).matches;

    const resize = () => {
      const rect = wrap.getBoundingClientRect();
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      sizeRef.current = { w: rect.width, h: rect.height };
      canvas.width = Math.max(1, Math.round(rect.width * dpr));
      canvas.height = Math.max(1, Math.round(rect.height * dpr));
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      drawRef.current();
    };
    resize();
    const observer = new ResizeObserver(resize);
    observer.observe(wrap);
    try {
      const saved = Number(window.localStorage.getItem(BEST_KEY));
      if (Number.isFinite(saved) && saved > 0) {
        bestRef.current = saved;
        setBest(saved);
      }
    } catch {}
    return () => {
      observer.disconnect();
      cancelAnimationFrame(rafRef.current);
    };
  }, []);

  const step = (time: number) => {
    if (statusRef.current !== "playing") return;
    const dt = Math.min((time - lastRef.current) / 1000, 0.05);
    lastRef.current = time;
    update(dt);
    draw();
    if (statusRef.current === "playing") {
      rafRef.current = requestAnimationFrame(step);
    }
  };

  const startGame = () => {
    worldRef.current = freshWorld();
    scoreRef.current = 0;
    setScore(0);
    setCombo(0);
    setLives(MAX_ESCAPES);
    timeShownRef.current = GAME_TIME;
    setTimeLeft(GAME_TIME);
    statusRef.current = "playing";
    setStatus("playing");
    lastRef.current = performance.now();
    cancelAnimationFrame(rafRef.current);
    rafRef.current = requestAnimationFrame(step);
  };

  const handlePointerDown = (event: React.PointerEvent<HTMLCanvasElement>) => {
    if (statusRef.current !== "playing") return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const px = event.clientX - rect.left;
    const py = event.clientY - rect.top;
    const world = worldRef.current;
    for (let i = world.cubes.length - 1; i >= 0; i--) {
      const cube = world.cubes[i];
      const pad = cube.size / 2 + 10;
      if (
        Math.abs(px - cube.x) <= pad &&
        Math.abs(py - cubeY(cube, world.elapsed)) <= pad
      ) {
        smash(cube, i);
        return;
      }
    }
    world.combo = 0;
    setCombo(0);
    for (let i = 0; i < 4; i++) {
      const life = 0.25;
      world.particles.push({
        x: px,
        y: py,
        vx: (Math.random() - 0.5) * 160,
        vy: (Math.random() - 0.5) * 160,
        size: 1.5 + Math.random() * 2,
        rot: 0,
        vrot: 0,
        life,
        maxLife: life,
        color: "#94a3b8",
        spark: true,
      });
    }
  };

  return (
    <div>
      <div className="mb-4 flex flex-wrap items-end justify-between gap-3">
        <div className="flex items-end gap-6">
          <div>
            <p className="text-[11px] font-semibold uppercase tracking-[0.2em] text-slate-500">
              Очки
            </p>
            <p className="font-display text-2xl text-white">{score}</p>
          </div>
          <div>
            <p className="text-[11px] font-semibold uppercase tracking-[0.2em] text-slate-500">
              Рекорд
            </p>
            <p className="font-display text-2xl text-cyan-300">{best}</p>
          </div>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          {combo >= 2 && (
            <span className="rounded-full border border-fuchsia-400/40 bg-fuchsia-500/10 px-3 py-1 text-sm font-semibold text-fuchsia-300">
              Комбо ×{combo}
            </span>
          )}
          <span className="rounded-full border border-white/10 bg-white/5 px-3 py-1 font-display text-sm text-slate-300">
            {timeLeft} с
          </span>
          <span
            className="flex items-center gap-1"
            role="img"
            aria-label={`Осталось жизней: ${lives} из ${MAX_ESCAPES}`}
          >
            {Array.from({ length: MAX_ESCAPES }, (_, i) => (
              <Heart
                key={i}
                className={
                  i < lives
                    ? "size-4 fill-rose-500 text-rose-500"
                    : "size-4 text-slate-700"
                }
                aria-hidden
              />
            ))}
          </span>
        </div>
      </div>
      <div
        ref={wrapRef}
        className="relative h-80 w-full overflow-hidden rounded-2xl border border-white/10 bg-[#0b0f1e] shadow-[0_0_44px_rgba(34,211,238,0.1)] sm:h-[420px]"
        style={{
          backgroundImage:
            "linear-gradient(rgba(148,163,184,0.07) 1px, transparent 1px), linear-gradient(90deg, rgba(148,163,184,0.07) 1px, transparent 1px)",
          backgroundSize: "64px 64px",
        }}
      >
        <canvas
          ref={canvasRef}
          onPointerDown={handlePointerDown}
          className="absolute inset-0 h-full w-full cursor-crosshair touch-none select-none"
          aria-label="Игровое поле: кликайте по кубам, чтобы разбивать их"
        />
        {status !== "playing" && (
          <div className="absolute inset-0 z-10 flex flex-col items-center justify-center gap-4 bg-slate-950/70 px-6 text-center backdrop-blur-sm">
            {status === "idle" ? (
              <>
                <p className="text-xs font-bold uppercase tracking-[0.3em] text-cyan-300">
                  Мини-игра
                </p>
                <h3 className="font-display text-2xl uppercase tracking-wide text-white sm:text-3xl">
                  Разбей куб
                </h3>
                <p className="max-w-sm text-sm text-slate-400">
                  Кликайте по кубам, пока они не улетели за край. Комбо из пяти
                  попаданий даёт бонусные очки, а пять улетевших кубов завершают
                  игру.
                </p>
                <div className="mt-1 flex flex-wrap items-center justify-center gap-2.5">
                  <button
                    type="button"
                    onClick={startGame}
                    className="inline-flex items-center gap-2 rounded-full bg-cyan-400 px-6 py-2.5 text-sm font-semibold text-slate-950 transition-colors hover:bg-cyan-300"
                  >
                    <MousePointerClick className="size-4" aria-hidden />
                    Играть
                  </button>
                  <a
                    href="#rules"
                    className="inline-flex items-center gap-2 rounded-full bg-cyan-400 px-6 py-2.5 text-sm font-semibold text-slate-950 transition-colors hover:bg-cyan-300"
                  >
                    <BookOpen className="size-4" aria-hidden />
                    Правила
                  </a>
                </div>
              </>
            ) : (
              <>
                <h3 className="font-display text-xl uppercase tracking-wide text-white sm:text-2xl">
                  {endTitle}
                </h3>
                <p className="font-display text-5xl text-cyan-300">{score}</p>
                <p className="inline-flex items-center gap-2 text-sm text-slate-400">
                  <Trophy className="size-4 text-amber-300" aria-hidden />
                  Рекорд: {best}
                </p>
                <div className="mt-1 flex flex-wrap items-center justify-center gap-2.5">
                  <button
                    type="button"
                    onClick={startGame}
                    className="inline-flex items-center gap-2 rounded-full bg-cyan-400 px-6 py-2.5 text-sm font-semibold text-slate-950 transition-colors hover:bg-cyan-300"
                  >
                    <RotateCcw className="size-4" aria-hidden />
                    Играть ещё
                  </button>
                  <a
                    href="#rules"
                    className="inline-flex items-center gap-2 rounded-full bg-cyan-400 px-6 py-2.5 text-sm font-semibold text-slate-950 transition-colors hover:bg-cyan-300"
                  >
                    <BookOpen className="size-4" aria-hidden />
                    Правила
                  </a>
                </div>
              </>
            )}
          </div>
        )}
      </div>
      <p className="mt-3 flex items-center gap-2 text-sm text-slate-500">
        <MousePointerClick className="size-4 shrink-0" aria-hidden />
        Работает и на телефоне: просто тапайте по кубам на игровом поле.
      </p>
    </div>
  );
}

export function MiniGame() {
  return (
    <section id="game" className="scroll-mt-32">
      <div className="mx-auto max-w-6xl px-4 py-16 sm:py-20">
        <SectionHeading
          kicker="Мини-игра"
          title="Разбей куб"
          description="Кубы летят по трассе — успейте разбить каждый кликом. Попадание рассыпает куб на неоновые осколки, искры и ударную волну, а комбо приносит бонусные очки."
        />
        <GameCanvas />
      </div>
    </section>
  );
}
