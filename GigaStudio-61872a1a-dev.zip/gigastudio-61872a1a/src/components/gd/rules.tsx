import type { LucideIcon } from "lucide-react";
import {
  Flag,
  MousePointerClick,
  Music,
  Percent,
  RotateCcw,
  Star,
} from "lucide-react";
import { gameRules } from "@/lib/gd-data";
import { SectionHeading } from "./section-heading";

const icons: Record<(typeof gameRules)[number]["icon"], LucideIcon> = {
  tap: MousePointerClick,
  restart: RotateCcw,
  rhythm: Music,
  percent: Percent,
  practice: Flag,
  stars: Star,
};

export function Rules() {
  return (
    <section id="rules" className="scroll-mt-32 border-t border-white/5">
      <div className="mx-auto max-w-6xl px-4 py-16 sm:py-20">
        <SectionHeading
          kicker="Правила"
          title="Правила игры"
          description="Простые законы, по которым устроен каждый уровень: одно касание, один ритм и никаких сохранений."
        />
        <ol className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {gameRules.map((rule, index) => {
            const Icon = icons[rule.icon];
            return (
              <li
                key={rule.title}
                className="rounded-xl border border-white/10 bg-white/5 p-5 transition-colors hover:border-cyan-400/40 hover:bg-cyan-400/5"
              >
                <div className="flex items-start justify-between">
                  <span className="grid size-11 place-items-center rounded-lg bg-gradient-to-br from-cyan-400/25 to-fuchsia-500/20 text-cyan-300">
                    <Icon className="size-5" aria-hidden />
                  </span>
                  <span
                    aria-hidden
                    className="font-display text-3xl leading-none text-white/10"
                  >
                    {index + 1}
                  </span>
                </div>
                <h3 className="mt-4 font-display text-base uppercase tracking-wide text-white">
                  {rule.title}
                </h3>
                <p className="mt-2 text-sm text-slate-400">{rule.text}</p>
              </li>
            );
          })}
        </ol>
      </div>
    </section>
  );
}
