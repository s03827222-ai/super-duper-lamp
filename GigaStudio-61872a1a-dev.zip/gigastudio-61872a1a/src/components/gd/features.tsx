import type { LucideIcon } from "lucide-react";
import { Globe, Hammer, Palette, Star, Target, Trophy } from "lucide-react";
import { extraFeatures } from "@/lib/gd-data";
import { SectionHeading } from "./section-heading";

const icons: Record<(typeof extraFeatures)[number]["icon"], LucideIcon> = {
  star: Star,
  palette: Palette,
  hammer: Hammer,
  globe: Globe,
  target: Target,
  trophy: Trophy,
};

export function Features() {
  return (
    <section id="features" className="scroll-mt-32 border-t border-white/5">
      <div className="mx-auto max-w-6xl px-4 py-16 sm:py-20">
        <SectionHeading
          kicker="Возможности"
          title="Чем заниматься кроме уровней"
          description="Geometry Dash — это не только 22 трассы: здесь есть коллекционирование, редактор и бесконечный поток контента от сообщества."
        />
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {extraFeatures.map((feature) => {
            const Icon = icons[feature.icon];
            return (
              <article
                key={feature.title}
                className="rounded-xl border border-white/10 bg-white/5 p-5 transition-colors hover:border-fuchsia-400/40 hover:bg-fuchsia-500/5"
              >
                <span className="grid size-11 place-items-center rounded-lg bg-gradient-to-br from-fuchsia-500/25 to-cyan-400/20 text-fuchsia-300">
                  <Icon className="size-5" aria-hidden />
                </span>
                <h3 className="mt-4 font-display text-base uppercase tracking-wide text-white">
                  {feature.title}
                </h3>
                <p className="mt-2 text-sm text-slate-400">{feature.text}</p>
              </article>
            );
          })}
        </div>
      </div>
    </section>
  );
}
