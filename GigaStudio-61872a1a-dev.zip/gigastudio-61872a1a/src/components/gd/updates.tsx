import { timeline } from "@/lib/gd-data";
import { SectionHeading } from "./section-heading";

export function Updates() {
  return (
    <section id="updates" className="scroll-mt-32">
      <div className="mx-auto max-w-6xl px-4 py-16 sm:py-20">
        <SectionHeading
          kicker="Обновления"
          title="История игры по версиям"
          description="От скромного релиза 2013 года до обновления 2.2, которого игроки ждали почти семь лет."
        />
        <ol className="relative space-y-8 border-l border-white/10 pl-6 sm:pl-10">
          {timeline.map((entry) => (
            <li key={entry.version} className="relative">
              <span
                aria-hidden
                className="absolute -left-[31px] top-1.5 size-3 rounded-full bg-cyan-400 shadow-[0_0_12px_rgba(34,211,238,0.8)] sm:-left-[47px]"
              />
              <div className="rounded-xl border border-white/10 bg-white/5 p-5">
                <div className="flex flex-wrap items-baseline gap-x-3 gap-y-1">
                  <span className="font-display text-lg text-cyan-300">
                    {entry.version}
                  </span>
                  <span className="rounded-full border border-white/10 px-2 py-0.5 text-xs text-slate-400">
                    {entry.year}
                  </span>
                  <h3 className="font-display text-base uppercase tracking-wide text-white">
                    {entry.title}
                  </h3>
                </div>
                <ul className="mt-3 space-y-1.5">
                  {entry.points.map((point) => (
                    <li
                      key={point}
                      className="flex gap-2 text-sm text-slate-400"
                    >
                      <span
                        aria-hidden
                        className="mt-[7px] size-1.5 shrink-0 rounded-full bg-cyan-400/70"
                      />
                      {point}
                    </li>
                  ))}
                </ul>
              </div>
            </li>
          ))}
        </ol>
      </div>
    </section>
  );
}
