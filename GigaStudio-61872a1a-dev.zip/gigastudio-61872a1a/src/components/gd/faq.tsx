import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { faq } from "@/lib/gd-data";
import { SectionHeading } from "./section-heading";

export function Faq() {
  return (
    <section id="faq" className="scroll-mt-32 border-t border-white/5">
      <div className="mx-auto max-w-6xl px-4 py-16 sm:py-20">
        <SectionHeading
          kicker="FAQ"
          title="Частые вопросы"
          description="Коротко о самом важном: цена, уровни, демоны и музыка."
        />
        <Accordion type="single" collapsible className="rounded-xl border border-white/10 bg-white/5 px-5">
          {faq.map((item, index) => (
            <AccordionItem
              key={item.q}
              value={`faq-${index}`}
              className="border-white/10 last:border-b-0"
            >
              <AccordionTrigger className="py-4 text-left text-sm font-semibold text-white hover:text-cyan-300 hover:no-underline sm:text-base">
                {item.q}
              </AccordionTrigger>
              <AccordionContent className="pb-5 text-sm leading-relaxed text-slate-400">
                {item.a}
              </AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>
      </div>
    </section>
  );
}
