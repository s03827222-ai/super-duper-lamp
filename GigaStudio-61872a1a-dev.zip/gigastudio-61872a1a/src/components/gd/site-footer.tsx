import { ExternalLink } from "lucide-react";
import { externalLinks } from "@/lib/gd-data";

const links = [
  { href: externalLinks.play, label: "Steam" },
  { href: externalLinks.appstore, label: "App Store" },
  { href: externalLinks.googleplay, label: "Google Play" },
  { href: externalLinks.site, label: "robtopgames.com" },
];

export function SiteFooter() {
  return (
    <footer className="border-t border-white/10 bg-black/30">
      <div className="mx-auto flex max-w-6xl flex-col gap-6 px-4 py-10 sm:flex-row sm:items-start sm:justify-between">
        <div>
          <p className="font-display text-sm uppercase tracking-wider text-white">
            Geometry Dash
          </p>
          <p className="mt-2 max-w-md text-sm text-slate-500">
            Неофициальный фан-сайт. Игра Geometry Dash создана Робертом Топалой
            (RobTop Games); все права на игру и музыку принадлежат их
            правообладателям.
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          {links.map((link) => (
            <a
              key={link.href}
              href={link.href}
              target="_blank"
              rel="noreferrer"
              className="inline-flex items-center gap-1.5 rounded-full border border-white/10 px-3 py-1.5 text-sm text-slate-300 transition-colors hover:bg-white/10 hover:text-white"
            >
              {link.label}
              <ExternalLink className="size-3.5" aria-hidden />
            </a>
          ))}
        </div>
      </div>
    </footer>
  );
}
