import type { LucideIcon } from "lucide-react";
import {
  Bot,
  Box,
  Bug,
  CircleDot,
  Orbit,
  Rocket,
  Ship,
  Waves,
} from "lucide-react";
import { gameModes, portalChips } from "@/lib/gd-data";
import { SectionHeading } from "./section-heading";

const icons: Record<string, LucideIcon> = {
  cube: Box,
  ship: Ship,
  ball: CircleDot,
  ufo: Rocket,
  robot: Bot,
  wave: Waves,
  spider: Bug,
  swing: Orbit,
};

export function Modes() {
  return (
    <section id="modes" className="scroll-mt-32">
      <div className="mx-auto max-w-6xl px-4 py-16 sm:py-20">
        <SectionHeading
          kicker="Режимы игры"
          title="Восемь способов передвигаться"
          description="Порталы на трассе переключают форму персонажа. Управление всегда одно — тап или удержание, но физика у каждого режима своя."
        />
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {gameModes.map((mode) => {
            const Icon = icons[mode.id] ?? Box;
            return (
              <article
                key={mode.id}
                className="flex flex-col rounded-xl border border-white/10 bg-white/5 p-5 transition-colors hover:border-cyan-300/40 hover:bg-cyan-400/5"
              >
                <div className="flex items-center justify-between">
                  <span className="grid size-11 place-items-center rounded-lg bg-gradient-to-br from-cyan-400/25 to-fuchsia-500/20 text-cyan-300">
                    <Icon className="size-5" aria-hidden />
                  </span>
                  <span className="rounded-full border border-white/10 px-2 py-0.5 text-xs text-slate-400">
                    {mode.version}
                  </span>
                </div>
                <h3 className="mt-4 font-display text-base uppercase tracking-wide text-white">
                  {mode.name}
                  <span className="ml-2 text-xs font-normal normal-case text-slate-500">
                    {mode.en}
                  </span>
                </h3>
                <p className="mt-2 text-sm font-medium text-cyan-300/90">
                  {mode.control}
                </p>
                <p className="mt-2 text-sm text-slate-400">{mode.description}</p>
              </article>
            );
          })}
        </div>
        <div className="mt-8 rounded-xl border border-white/10 bg-white/5 p-5">
          <p className="text-xs font-bold uppercase tracking-[0.2em] text-slate-500">
            Что ещё меняют порталы
          </p>
          <div className="mt-3 flex flex-wrap gap-2">
            {portalChips.map((chip) => (
              <span
                key={chip}
                className="rounded-full border border-cyan-300/30 bg-cyan-400/10 px-3 py-1 text-sm text-cyan-200"
              >
                {chip}
              </span>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
