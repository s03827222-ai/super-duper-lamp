export function SectionHeading({
  kicker,
  title,
  description,
}: {
  kicker: string;
  title: string;
  description?: string;
}) {
  return (
    <div className="mb-10 max-w-2xl">
      <p className="mb-2 text-xs font-bold uppercase tracking-[0.2em] text-cyan-400">
        {kicker}
      </p>
      <h2 className="font-display text-2xl uppercase leading-snug text-white sm:text-3xl">
        {title}
      </h2>
      {description ? (
        <p className="mt-3 text-slate-400">{description}</p>
      ) : null}
    </div>
  );
}
