export type DifficultyId =
  | "easy"
  | "normal"
  | "hard"
  | "harder"
  | "insane"
  | "demon";

export const difficulties: {
  id: DifficultyId;
  name: string;
  color: string;
  stars: string;
  description: string;
}[] = [
  {
    id: "easy",
    name: "Easy",
    color: "#38bdf8",
    stars: "1–2 ★",
    description:
      "Уровни для знакомства с игрой: редкие препятствия и щедрый ритм.",
  },
  {
    id: "normal",
    name: "Normal",
    color: "#4ade80",
    stars: "3–4 ★",
    description:
      "Появляются первые связки прыжков и порталы смены режима.",
  },
  {
    id: "hard",
    name: "Hard",
    color: "#fbbf24",
    stars: "5–6 ★",
    description: "Плотный ритм, шипы и блоки начинают требовать тайминга.",
  },
  {
    id: "harder",
    name: "Harder",
    color: "#f87171",
    stars: "7–10 ★",
    description: "Скоростные смены режима, узкие проходы и длинные связки.",
  },
  {
    id: "insane",
    name: "Insane",
    color: "#e879f9",
    stars: "10–12 ★",
    description: "Хаос из порталов и двойных режимов. Здесь нужно мышечное памятно.",
  },
  {
    id: "demon",
    name: "Demon",
    color: "#ef4444",
    stars: "14–15 ★",
    description:
      "Высшая сложность игры. Сообщество делит демонов от Easy до Extreme.",
  },
];

export type GameMode = {
  id: string;
  name: string;
  en: string;
  control: string;
  description: string;
  version: string;
};

export const gameModes: GameMode[] = [
  {
    id: "cube",
    name: "Куб",
    en: "Cube",
    control: "Тап — прыжок",
    description:
      "Базовый режим: прыгает по тапу и умирает от любого касания шипов.",
    version: "с 1.0",
  },
  {
    id: "ship",
    name: "Корабль",
    en: "Ship",
    control: "Держать — лететь вверх",
    description:
      "Летит, пока удерживаешь палец; отпустил — плавно снижается.",
    version: "с 1.0",
  },
  {
    id: "ball",
    name: "Шар",
    en: "Ball",
    control: "Тап — переворот гравитации",
    description:
      "Катится по полу и потолку, на каждом тапе меняет гравитацию.",
    version: "с 1.0",
  },
  {
    id: "ufo",
    name: "НЛО",
    en: "UFO",
    control: "Тап — рывок вверх",
    description:
      "Каждый тап — маленький прыжок в воздухе, похожий на флаппи-полёт.",
    version: "с 1.3",
  },
  {
    id: "robot",
    name: "Робот",
    en: "Robot",
    control: "Держать — выше прыжок",
    description:
      "Прыгает, как куб, но высота прыжка зависит от длительности удержания.",
    version: "с 1.6",
  },
  {
    id: "wave",
    name: "Волна",
    en: "Wave",
    control: "Держать — вверх, отпустить — вниз",
    description:
      "Летит строго по диагонали и оставляет след. Самая точная и хрупкая форма.",
    version: "с 1.9",
  },
  {
    id: "spider",
    name: "Паук",
    en: "Spider",
    control: "Тап — телепорт на другую сторону",
    description:
      "Мгновенно телепортируется на пол или потолок, меняя гравитацию.",
    version: "с 2.1",
  },
  {
    id: "swing",
    name: "Свинг",
    en: "Swing",
    control: "Держать и отпускать — взмахи",
    description:
      "Новинка 2.2: качается вверх и вниз, как маятник, не прыгая вовсе.",
    version: "с 2.2",
  },
];

export const portalChips = [
  "Скорость: ×0.5, ×1, ×2, ×3, ×4",
  "Портал гравитации",
  "Мини-портал",
  "Телепорт-портал",
  "Двойной режим (Dual)",
];

export const gameRules: {
  icon: "tap" | "restart" | "rhythm" | "percent" | "practice" | "stars";
  title: string;
  text: string;
}[] = [
  {
    icon: "tap",
    title: "Одно касание — одно действие",
    text: "Вся игра держится на одном тапе: прыжок, полёт корабля или переворот гравитации. Сложность не в управлении, а в точном тайминге.",
  },
  {
    icon: "restart",
    title: "Ошибка — начало уровня",
    text: "Касание шипа, удар в блок или падение за край экрана мгновенно перезапускает трассу. Прогресс в обычном режиме не сохраняется.",
  },
  {
    icon: "rhythm",
    title: "Двигайся по ритму",
    text: "Препятствия подогнаны под бит музыки: если слушать трек, мелодия сама подсказывает момент прыжка.",
  },
  {
    icon: "percent",
    title: "Проценты вместо жизней",
    text: "Жизней здесь нет — прогресс уровня измеряется в процентах от старта до финиша. 100% — трасса пройдена.",
  },
  {
    icon: "practice",
    title: "Практика с чекпоинтами",
    text: "В режиме практики можно ставить чекпоинты и разучивать сложные куски, а потом собирать уровень целиком.",
  },
  {
    icon: "stars",
    title: "Награда — звёзды и монеты",
    text: "За прохождение дают звёзды по сложности уровня, а на самой трассе спрятаны три секретные монеты для коллекционеров.",
  },
];

export type Level = {
  n: number;
  name: string;
  difficulty: DifficultyId;
  stars: number;
  version: string;
  song: string;
};

export const levels: Level[] = [
  { n: 1, name: "Stereo Madness", difficulty: "easy", stars: 1, version: "1.0", song: "ForeverBound — Stereo Madness" },
  { n: 2, name: "Back On Track", difficulty: "easy", stars: 2, version: "1.0", song: "DJVI — Back On Track" },
  { n: 3, name: "Polargeist", difficulty: "normal", stars: 3, version: "1.0", song: "Step — Polargeist" },
  { n: 4, name: "Dry Out", difficulty: "normal", stars: 4, version: "1.0", song: "DJVI — Dry Out" },
  { n: 5, name: "Base After Base", difficulty: "hard", stars: 5, version: "1.0", song: "DJVI — Base After Base" },
  { n: 6, name: "Cant Let Go", difficulty: "hard", stars: 6, version: "1.0", song: "DJVI — Cant Let Go" },
  { n: 7, name: "Jumper", difficulty: "harder", stars: 7, version: "1.0", song: "Waterflame — Jumper" },
  { n: 8, name: "Time Machine", difficulty: "harder", stars: 8, version: "1.0", song: "Waterflame — Time Machine" },
  { n: 9, name: "Cycles", difficulty: "harder", stars: 9, version: "1.0", song: "DJVI — Cycles" },
  { n: 10, name: "xStep", difficulty: "insane", stars: 10, version: "1.1", song: "DJVI — xStep" },
  { n: 11, name: "Clutterfunk", difficulty: "insane", stars: 11, version: "1.2", song: "Waterflame — Clutterfunk" },
  { n: 12, name: "Theory of Everything", difficulty: "insane", stars: 12, version: "1.3", song: "DJVI — Theory of Everything" },
  { n: 13, name: "Electroman Adventures", difficulty: "insane", stars: 10, version: "1.4", song: "Waterflame — Electroman Adventures" },
  { n: 14, name: "Clubstep", difficulty: "demon", stars: 14, version: "1.5", song: "DJ-Nate — Clubstep" },
  { n: 15, name: "Electrodynamix", difficulty: "insane", stars: 12, version: "1.6", song: "DJ-Nate — Electrodynamix" },
  { n: 16, name: "Hexagon Force", difficulty: "insane", stars: 12, version: "1.7", song: "Waterflame — Hexagon Force" },
  { n: 17, name: "Blast Processing", difficulty: "harder", stars: 10, version: "1.8", song: "Waterflame — Blast Processing" },
  { n: 18, name: "Theory of Everything 2", difficulty: "demon", stars: 14, version: "1.9", song: "DJ-Nate — Theory of Everything 2" },
  { n: 19, name: "Geometrical Dominator", difficulty: "harder", stars: 10, version: "2.0", song: "Waterflame — Geometrical Dominator" },
  { n: 20, name: "Deadlocked", difficulty: "demon", stars: 15, version: "2.0", song: "F-777 — Deadlocked" },
  { n: 21, name: "Fingerdash", difficulty: "insane", stars: 12, version: "2.1", song: "MDK — Press Start" },
  { n: 22, name: "Dash", difficulty: "insane", stars: 12, version: "2.2", song: "Саундтрек обновления 2.2" },
];

export const extraFeatures: {
  icon: "star" | "palette" | "hammer" | "globe" | "target" | "trophy";
  title: string;
  text: string;
}[] = [
  {
    icon: "star",
    title: "Звёзды, монеты и алмазы",
    text: "Звёзды дают пройденные уровни, секретные монеты прячутся на трассах, а алмазы — награда за ежедневные задания. Сферы маны тратятся в магазинах.",
  },
  {
    icon: "palette",
    title: "Кастомизация иконок",
    text: "Кубы, корабли, цвета и следы — тысячи комбинаций. Часть открывается достижениями, часть покупается за собранные сферы.",
  },
  {
    icon: "hammer",
    title: "Редактор уровней",
    text: "Стройте свои уровни и публикуйте их онлайн. В 2.2 редактор получил триггеры, платформенный режим и море новых объектов.",
  },
  {
    icon: "globe",
    title: "Онлайн-контент",
    text: "Ежедневные уровни, недельный демон, события, гаунтлеты, мампаки и рейтинги — контент от игроков не заканчивается никогда.",
  },
  {
    icon: "target",
    title: "Режим практики",
    text: "Тренировка с чекпоинтами: разучите сложные места по кускам, а потом соберите уровень целиком в обычном режиме.",
  },
  {
    icon: "trophy",
    title: "Достижения и сейфы",
    text: "Сотни достижений с наградами и секретные «сейфы» с кодовыми словами, где спрятаны уникальные иконки.",
  },
];

export const timeline: {
  version: string;
  year: string;
  title: string;
  points: string[];
}[] = [
  {
    version: "1.0",
    year: "2013",
    title: "Релиз",
    points: [
      "13 августа 2013 — выход на iOS, позже Android и Steam",
      "Семь уровней: от Stereo Madness до Jumper",
      "Три режима: куб, корабль и шар",
    ],
  },
  {
    version: "1.1–1.9",
    year: "2013–2015",
    title: "Первые большие обновления",
    points: [
      "Новые режимы: НЛО, робот и волна",
      "Первый официальный демон — Clubstep",
      "Уровни вплоть до Theory of Everything 2",
    ],
  },
  {
    version: "2.0",
    year: "2015",
    title: "Эра кастомизации",
    points: [
      "Уровни Geometrical Dominator и Deadlocked",
      "Пользовательские монеты и новые иконки",
      "Больше объектов и эффектов для уровней игроков",
    ],
  },
  {
    version: "2.1",
    year: "2017",
    title: "Пауки и магазины",
    points: [
      "Уровень Fingerdash и режим паука",
      "Магазины иконок и сейфы с секретами",
      "Уровень The Challenge для самых упорных",
    ],
  },
  {
    version: "2.2",
    year: "2023",
    title: "Платформенный режим",
    points: [
      "Самое долгожданное обновление — через семь лет",
      "Новый уровень Dash, режим свинга и платформенные уровни",
      "Полностью переработанный редактор с триггерами",
    ],
  },
];

export const faq: { q: string; a: string }[] = [
  {
    q: "Что такое Geometry Dash?",
    a: "Ритм-платформер Роберта Топалы (RobTop Games), вышедший в 2013 году. Квадратик бежит под музыку, вы прыгаете в такт, а любая ошибка отправляет в начало уровня. Простая идея — и очень сложное прохождение.",
  },
  {
    q: "Игра бесплатная?",
    a: "Основная Geometry Dash — платная разовая покупка на iOS, Android и в Steam, без обязательных внутренних покупок. Есть бесплатные спин-оффы: Geometry Dash Lite, World, Meltdown и SubZero.",
  },
  {
    q: "Сколько в игре уровней?",
    a: "22 официальных основных уровня, плюс секретные: The Challenge и башня из обновления 2.2. Сверх этого — бесконечный поток уровней от игроков: новые выходят каждый день.",
  },
  {
    q: "Что такое демон?",
    a: "Самая высокая сложность в игре. Демоны — уровни для опытных игроков; сообщество дополнительно делит их от Easy Demon до Extreme Demon. Первый официальный демон — Clubstep.",
  },
  {
    q: "Как проходить сложные места?",
    a: "Включайте режим практики с чекпоинтами и разучивайте трассу по кускам. Слушайте ритм: почти все препятствия синхронизированы с музыкой, и она подсказывает момент прыжка.",
  },
  {
    q: "Кто сделал музыку?",
    a: "Для официальных уровней RobTop использовал треки известных электронных артистов: DJVI, Waterflame, DJ-Nate, F-777, MDK и других. В уровнях игроков — музыка с Newgrounds и других площадок.",
  },
  {
    q: "На каких платформах выходит игра?",
    a: "iOS и Android, а также Windows и macOS в Steam. Отдельными приложениями выходили Lite, World, Meltdown и SubZero со своими наборами уровней.",
  },
];

export const aboutFacts: {
  icon: "dev" | "date" | "genre" | "platforms";
  label: string;
  value: string;
}[] = [
  { icon: "dev", label: "Разработчик", value: "RobTop Games (Роберт Топала)" },
  { icon: "date", label: "Дата выхода", value: "13 августа 2013" },
  { icon: "genre", label: "Жанр", value: "Ритм-платформер" },
  { icon: "platforms", label: "Платформы", value: "iOS • Android • Windows • macOS" },
];

export const externalLinks = {
  play: "https://store.steampowered.com/app/322170/Geometry_Dash/",
  site: "https://robtopgames.com",
  appstore: "https://apps.apple.com/app/geometry-dash/id637958136",
  googleplay:
    "https://play.google.com/store/apps/details?id=com.robtopx.geometryjump",
};
