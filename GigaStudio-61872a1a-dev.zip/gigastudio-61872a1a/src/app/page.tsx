import { SiteHeader } from "@/components/gd/site-header";
import { SiteFooter } from "@/components/gd/site-footer";
import { Hero } from "@/components/gd/hero";
import { About } from "@/components/gd/about";
import { Rules } from "@/components/gd/rules";
import { Modes } from "@/components/gd/modes";
import { Difficulties } from "@/components/gd/difficulties";
import { Levels } from "@/components/gd/levels";
import { MiniGame } from "@/components/gd/mini-game";
import { Features } from "@/components/gd/features";
import { Updates } from "@/components/gd/updates";
import { Faq } from "@/components/gd/faq";

export default function IndexPage() {
  return (
    <div className="flex min-h-screen flex-col bg-[#0b0f1e]">
      <SiteHeader />
      <main className="flex-1">
        <Hero />
        <About />
        <Rules />
        <Modes />
        <Difficulties />
        <Levels />
        <MiniGame />
        <Features />
        <Updates />
        <Faq />
      </main>
      <SiteFooter />
    </div>
  );
}
